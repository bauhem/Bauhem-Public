# Activate and configure extensions
# https://middlemanapp.com/advanced/configuration/#configuring-extensions

require 'redcarpet'
require "sanitize"


activate :autoprefixer do |prefix|
  prefix.browsers = "last 2 versions"
end
# Layouts
# https://middlemanapp.com/basics/layouts/

# Per-page layout changes
page '/*.xml', layout: false
page '/*.json', layout: false
page '/*.txt', layout: false

set :url_root, 'https://robber-sylvia-62762.netlify.com/'
set :js_dir, 'javascripts'
set :index_file, "index.html"

activate :dato, live_reload: true, token: '98a9bd9ed6d1ba888f9f'
activate :i18n, langs: [:fr, :en]
activate :directory_indexes
activate :search_engine_sitemap
set :markdown, :tables => true, :autolink => true, :gh_blockcode => true, :fenced_code_blocks => true, with_toc_data: true
set :markdown_engine, :redcarpet
set :relative_links, true



# Reload the browser automatically whenever files change
configure :development do
  activate :livereload
end


configure :build do
  activate :minify_css
  activate :minify_javascript
  activate :minify_html
  activate :relative_assets
  activate :asset_hash
end

page '/localizable/index.html', layout: 'layout'
page '/localizable/plans.html', layout: "interieur"
page '/localizable/regions.html', layout: "interieur"
page "/templates/plan.html", :layout => "interieur"
page "/templates/region.html", :layout => "interieur"
page "/templates/boutique.html", :layout => "interieur"
page "/templates/categories.html", :layout => "interieur"
page "/templates/categorie.html", :layout => "interieur"
page "/templates/produits.html", :layout => "interieur"
page "/templates/service.html", :layout => "interieur"
page "/templates/services.html", :layout => "interieur"
page "/templates/produit.html", :layout => "interieur"


page '/sitemap.xml', :layout => false

dato.tap do |dato|
  dato.available_locales.each do |locale|
    I18n.with_locale(locale) do
    # iterate over the "Blog post" records...
    dato.services.each do |service|
    # ...and create a page for each service starting from a template!
    proxy(
         "/#{locale}/#{service.slug}/index.html",
         "/templates/service.html",
         locals: { service: service },
         locale: locale
       )
     end
    end
  end
end

dato.tap do |dato|
  dato.available_locales.each do |locale|
    I18n.with_locale(locale) do
    # iterate over the "Blog post" records...
    dato.boutiques.each do |boutique|
    # ...and create a page for each service starting from a template!
    proxy(
         "/#{locale}/#{boutique.slug}/index.html",
         "/templates/boutique.html",
         locals: { boutique: boutique },
         locale: locale
       )
     end
    end
  end
end


dato.tap do |dato|
  dato.available_locales.each do |locale|
    I18n.with_locale(locale) do
    # iterate over the "Blog post" records...
    dato.regions.each do |region|
    # ...and create a page for each service starting from a template!
    proxy(
         "/#{locale}/regions/#{region.slug}/index.html",
         "/templates/region.html",
         locals: { region: region },
         locale: locale
       )
     end
    end
  end
end


dato.tap do |dato|
  dato.available_locales.each do |locale|
    I18n.with_locale(locale) do
    # iterate over the "Blog post" records...
    dato.categorie_de_produits.each do |cp|
    # ...and create a page for each service starting from a template!
    proxy(
         "/#{locale}/#{cp.categorie_principale.first.slug}/#{cp.slug}/index.html",
         "/templates/categories.html",
         locals: { cp: cp },
         locale: locale
       )
     end
    end
  end
end




dato.tap do |dato|
  dato.available_locales.each do |locale|
    I18n.with_locale(locale) do
    # iterate over the "Blog post" records...
    dato.produits.each do |produit|

    # ...and create a page for each service starting from a template!
    if produit.categorie.first != ""
      proxy(
           "/#{locale}/#{produit.categorie.first.categorie_principale.first.slug}/#{produit.categorie.first.slug}/#{produit.slug}/index.html",
           "/templates/produit.html",
           locals: { produit: produit },
           locale: locale
         )
      else
      end
     end
    end
  end
end


dato.tap do |dato|
  dato.available_locales.each do |locale|
    I18n.with_locale(locale) do
    # iterate over the "Blog post" records...
    dato.plans.each do |plan|
    # ...and create a page for each service starting from a template!
    proxy(
         "/#{locale}/#{plan.service.first.slug}/#{plan.slug}/index.html",
         "/templates/plan.html",
         locals: { plan: plan },
         locale: locale
       )
     end
    end
  end
end






# tell Middleman to ignore the template
ignore '/templates/*'

helpers do
  def strip_tags(html)
  Sanitize.clean(html.strip).strip
  end

  def truncate_words(text, options={})
  options.reverse_merge!(:length => 1, :omission => "")
  if text
    words = text.split()
    words[0..(options[:length]-1)].join(' ') + (words.length > options[:length] ? options[:omission] : '')
  end
  end

  def markdown(text)
    renderer = Redcarpet::Render::HTML.new
    Redcarpet::Markdown.new(renderer).render(text)
  end

  def image_or_missing(image)
    if image
      yield image
    else
      image_tag "/images/missing-image.png"
    end
  end

  def i18n_path(lang, path)
  translated_path = t("paths.#{path}", locale: lang)

  if lang.to_s == 'de'
    prefix = ''
  else
    prefix = "/#{lang}"
  end

  "#{prefix}/#{translated_path}"
  end
end
# With alternative layout
# page '/path/to/file.html', layout: 'other_layout'

# Proxy pages
# https://middlemanapp.com/advanced/dynamic-pages/

# proxy(
#   '/this-page-has-no-template.html',
#   '/template-file.html',
#   locals: {
#     which_fake_page: 'Rendering a fake page with a local variable'
#   },
# )
# Build-specific configuration


# Helpers
# Methods defined in the helpers block are available in templates
# https://middlemanapp.com/basics/helper-methods/

# helpers do
#   def some_helper
#     'Helping'
#   end
# end

# Build-specific configuration
# https://middlemanapp.com/advanced/configuration/#environment-specific-settings

# configure :build do
#   activate :minify_css
#   activate :minify_javascript
# end
